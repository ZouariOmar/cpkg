#!/usr/bin/env bash

# Template directory
TEMPLATE_DIR="generic-project-starter"
PROJECT_DESC=""
LINKEDIN_PROFILE=""
EMAIL_ADDRESS=""
AUTHOR_NAME=""
REMOTE_PROVIDER=""
USER_NAME=""
LICENSE_NAME=""

# Prompt for input
read -rp "Enter Project Name: " PROJECT_NAME

while true; do
  clear

  echo "=============================="
  echo "      Project Setup Menu"
  echo "=============================="
  echo "1) Project Description : ${PROJECT_DESC:-<empty>}"
  echo "2) LinkedIn            : ${LINKEDIN_PROFILE:-<empty>}"
  echo "3) Email Address       : ${EMAIL_ADDRESS:-<empty>}"
  echo "4) Author              : ${AUTHOR_NAME:-<empty>}"
  echo "5) Remote Provider     : ${REMOTE_PROVIDER:-<empty>}"
  echo "6) Username            : ${USER_NAME:-<empty>}"
  echo "7) License             : ${LICENSE_NAME:-<empty>}"
  echo
  echo "8) Continue"
  echo "0) Exit"
  echo

  read -rp "Choose an option: " choice

  case "$choice" in
  1)
    read -rp "Enter Project Description: " PROJECT_DESC
    ;;
  2)
    read -rp "Enter LinkedIn Profile: " LINKEDIN_PROFILE
    ;;
  3)
    read -rp "Enter Email Address: " EMAIL_ADDRESS
    ;;
  4)
    read -rp "Enter Author name: " AUTHOR_NAME
    ;;
  5)
    read -rp "Enter Git provider: " REMOTE_PROVIDER
    ;;
  6)
    read -rp "Enter username/org name: " USER_NAME
    ;;
  7)
    read -rp "Enter SPDX license ID: " LICENSE_NAME
    ./__license.sh "${LICENSE_NAME}" "${TEMPLATE_DIR}"
    ;;
  8)
    break
    ;;
  0)
    echo "Exiting..."
    exit 0
    ;;
  *)
    echo "Invalid option"
    sleep 1
    ;;
  esac
done

# Set default values for optional fields
: "${PROJECT_DESC:='UnknownProjectDesc'}"
: "${LINKEDIN_PROFILE:=UnknownLinkedinProfile}"
: "${EMAIL_ADDRESS:='Unknown@Email.Address'}"
: "${AUTHOR_NAME:='UnknownAuthorName'}"
: "${REMOTE_PROVIDER:='UnknownRemoteProvider'}"
: "${USER_NAME:='UnknownUserName'}"
: "${LICENSE_NAME:='UnknownLicenseName'}"

# Get current date
DATE=$(date +"%Y-%m-%d")
YEAR=$(date +"%Y")

# Validate PROJECT_NAME
if [ -z "$PROJECT_NAME" ]; then
  echo "[ERROR] Project name cannot be empty!"
  exit 1
fi

if [ ! -d "$TEMPLATE_DIR" ]; then
  echo "[ERROR] Template directory '$TEMPLATE_DIR' does not exist!"
  exit 1
fi

# Rename only root project folder
mv "$TEMPLATE_DIR" "$PROJECT_NAME"

# Function to replace placeholders in file contents
replace_in_file_contents() {
  local file="$1"
  if [ -f "$file" ]; then
    sed -i \
      -e "s|{{PROJECT_NAME}}|$PROJECT_NAME|g" \
      -e "s|{{PROJECT_DESC}}|$PROJECT_DESC|g" \
      -e "s|{{LINKEDIN_PROFILE}}|$LINKEDIN_PROFILE|g" \
      -e "s|{{EMAIL_ADDRESS}}|$EMAIL_ADDRESS|g" \
      -e "s|{{AUTHOR_NAME}}|$AUTHOR_NAME|g" \
      -e "s|{{REMOTE_PROVIDER}}|$REMOTE_PROVIDER|g" \
      -e "s|{{USER_NAME}}|$USER_NAME|g" \
      -e "s|{{LICENSE_NAME}}|$LICENSE_NAME|g" \
      -e "s|{{DATE}}|$DATE|g" \
      -e "s|{{YEAR}}|$YEAR|g" "$file"
  fi
}

# Replace placeholders in all files
find "$PROJECT_NAME" -type f | while read -r file; do
  replace_in_file_contents "$file"
done

# Remove tool files
rm __license.sh
