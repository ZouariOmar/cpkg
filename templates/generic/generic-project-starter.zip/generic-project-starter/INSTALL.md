# Installation

## Clone Repository

```bash
git https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}
cd {{PROJECT_NAME}}
```

## Requirements

- Git
- Docker (optional)
- Make

## Build

```bash
make build
```

## Run

```bash
make run
```

## Docker

```bash
make docker
```
