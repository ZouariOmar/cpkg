[![Contributors](https://img.shields.io/badge/CONTRIBUTORS-01-blue?style=plastic)](https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}/graphs/contributors)
[![Forks](https://img.shields.io/badge/FORKS-00-blue?style=plastic)](https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}/network/members)
[![Stargazers](https://img.shields.io/badge/STARS-00-blue?style=plastic)](https://github.com/{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}/stargazers)
[![Issues](https://img.shields.io/badge/ISSUES-00-blue?style=plastic)](https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}/issues)
[![GPL3.0 License](https://img.shields.io/badge/LICENSE-GPL3.0-blue?style=plastic)](https://raw.githubusercontent.com/{{MODULE_PATH}}/refs/heads/main/LICENSE)
[![Linkedin](https://img.shields.io/badge/Linkedin-7.2k-blue?style=plastic)](https://www.linkedin.com/in/{{LINKEDIN_PROFILE}})

<div align="center">

<img src="res/img/logo.png" width="300" alt="{{PROEJCT_NAME}}_logo">

<h1>{{PROJECT_NAME}}</h1>

<h4>{{PROJECT_DESC}}</h4>

![Project](https://img.shields.io/badge/project-generic-blue?style=for-the-badge&logo=github&logoColor=white)
![Open Source](https://img.shields.io/badge/open_source-yes-brightgreen?style=for-the-badge&logo=opensourceinitiative&logoColor=white)
![Status](https://img.shields.io/badge/status-active-success?style=for-the-badge&logo=statuspage&logoColor=white)
![Maintained](https://img.shields.io/badge/maintained-yes-blue?style=for-the-badge&logo=dependabot&logoColor=white)
![Version](https://img.shields.io/badge/version-0.1.0-orange?style=for-the-badge&logo=semver&logoColor=white)
![License](https://img.shields.io/badge/license-{{LICENSE_NAME}}-green?style=for-the-badge&logo=open-source-initiative&logoColor=white)
![Automation](https://img.shields.io/badge/category-automation-purple?style=for-the-badge&logo=githubactions&logoColor=white)
![Bash Script](https://img.shields.io/badge/bash_script-%23121011.svg?style=for-the-badge&logo=gnu-bash&logoColor=white)
![Docker](https://img.shields.io/badge/docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)
![Linux](https://img.shields.io/badge/linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
![DevOps](https://img.shields.io/badge/devops-automation-purple?style=for-the-badge&logo=devops&logoColor=white)
![Cross Platform](https://img.shields.io/badge/cross--platform-supported-success?style=for-the-badge&logo=windows-terminal&logoColor=white)
![Fast](https://img.shields.io/badge/performance-fast-brightgreen?style=for-the-badge&logo=speedtest&logoColor=white)
![Stable](https://img.shields.io/badge/build-stable-success?style=for-the-badge&logo=checkmarx&logoColor=white)
![Community](https://img.shields.io/badge/community-driven-blueviolet?style=for-the-badge&logo=githubsponsors&logoColor=white)

</div>

- [Overview](#overview)
- [Key Features](#key-features)
- [Usage](#usage)
- [Download](#download)
- [Emailware](#emailware)
- [Contributing](#contributing)
- [License](#license)
- [Contact](#contact)
- [Acknowledgments](#acknowledgments)

![screenshot](res/img/screenshot.png)

## Overview

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

## Key Features

Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

- [CMake](https://cmake.org)
- [Ninja](https://github.com/ninja-build/ninja)

## Usage

```bash
git clone https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}}
cd {{PROJECT_NAME}}

make
```

## Download

You can [download](https://github.com/{{MODULE_PATH}}/releases) the latest installable version of {{PROJECT_NAME}} for Windows, macOS and Linux.

## Emailware

{{PROJECT_NAME}} is an emailware. Meaning, if you liked using this app or it has helped you in any way,
would like you send as an email at <{{EMAIL_ADDRESS}}> about anything you'd want to say about
this software. I'd really appreciate it!

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This repository is licensed under the **{{LICENSE_NAME}}**. You are free to use, modify, and distribute the content. See the [LICENSE](LICENSE) file for details.

## Contact

For questions or suggestions, feel free to reach out:

- **{{REMOTE_PROVIDER}}**: [{{REMOTE_PROVIDER}}](https://{{REMOTE_PROVIDER}}/{{USER_NAME}}/{{PROJECT_NAME}})
- **Email**: <{{EMAIL_ADDRESS}}>
- **LinkedIn**: [{{LINKEDIN_PROFILE}}](https://www.linkedin.com/in/{{LINKEDIN_PROFILE}})

## Acknowledgments

Built with ❤️ for the open-source community.
