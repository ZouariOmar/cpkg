#!/usr/bin/env bash

LICENSE_NAME="$1"
OUTPUT_DIR="$2"

if [[ -z "$LICENSE_NAME" ]]; then
  echo "No license provided"
  exit 1
fi

OUTPUT_DIR="${OUTPUT_DIR:-.}"

mkdir -p "$OUTPUT_DIR"

LICENSE_URL="https://raw.githubusercontent.com/spdx/license-list-data/main/text/${LICENSE_NAME}.txt"

echo "Downloading $LICENSE_NAME license..."

if curl -fsSL "$LICENSE_URL" -o "$OUTPUT_DIR/LICENSE"; then
  echo "[INFO] LICENSE file created successfully!"
else
  echo "[ERROR] License not found: $LICENSE_NAME!"
  sleep
  exit 1
fi
